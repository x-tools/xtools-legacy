********************************************************************************
Check documentation for help on all topics:
http://www.amcharts.com/docs/

Incase you don't find something, post your questions to support forum:
http://www.amcharts.com/forum/

You can use amCharts visual editor to configure your charts:
http://extra.amcharts.com/editor/ 
********************************************************************************